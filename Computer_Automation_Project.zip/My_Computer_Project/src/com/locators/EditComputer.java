package com.locators;

import org.openqa.selenium.By;

public interface EditComputer {

	public static By UpdateComputerButton = By.cssSelector(".btn.primary");
	public static By EditHeader = By.name("Edit computer");
	public static By DeleteButton = By.xpath("//*[@id='main']/form[2]/input");
	
}
