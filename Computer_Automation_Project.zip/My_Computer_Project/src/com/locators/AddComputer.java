package com.locators;

import org.openqa.selenium.By;

public interface AddComputer {

	public static By ComputerName = By.id("name");
	public static By IntroducedDate = By.id("introduced");
	public static By DiscontinuedDate = By.id("discontinued");
	public static By Company = By.id("company");
	public static By CreateComputerButton = By.xpath("//*[@id='main']/form/div/input");
	public static By CancelButton = By.xpath("//*[@id='main']/form/div/a");
}
