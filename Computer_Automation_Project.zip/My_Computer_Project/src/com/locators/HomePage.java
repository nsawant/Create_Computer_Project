package com.locators;

import org.openqa.selenium.By;

public interface HomePage {
	
	public static By AddComputer_HomeButton = By.xpath("//*[@id='add']");				
	public static By PageHeader = By.linkText("Play sample application � Computer database");
	public static By Search_Button = By.id("searchsubmit");
	public static By Search_Box = By.id("searchbox");
	public static By Pagination = By.xpath("//*[@id='pagination']/ul/li[3]/a");
	public static By SearchResult = By.linkText("ABCorp");
	public static By SearchResultPresent= By.xpath("//*[@id='pagination']/ul/li[2]/a"); 
	public static By NewComputerConfirmation = By.xpath("//*[@id='main']/div[1]");
	public static By EditComputerConfirmation = By.xpath("//*[@id='main']/div[1]");
	public static By DeleteComputerConfirmation = By.xpath("//*[@id='main']/div[1]");
	public static By ReadSearchResult = By.xpath("//*[@id='main']/table/tbody/tr/td[1]");
	public static By NoDataFound = By.xpath("//*[@id='main']/div[2]");
}
