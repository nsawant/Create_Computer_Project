package com.methods;

import org.testng.Assert;

import com.locators.AddComputer;
import com.locators.EditComputer;
import com.utils.BaseClass;

public class EditPage extends BaseClass implements EditComputer, AddComputer{

	public static void VerifyDeleteButton(){
			boolean DeleteButtonPresent = driver.findElement(DeleteButton).isDisplayed();
			boolean DeleteButtonEnabled = driver.findElement(DeleteButton).isEnabled();
			if (DeleteButtonPresent == true && DeleteButtonEnabled == true){
				driver.findElement(DeleteButton).click();
			}else{
				System.out.println("Element not found");
			}
	}
	
	public static void UpdateComputerDetails(String ComputerUpdate, String IDate, String TDate){
		boolean DeleteButtonPresent = driver.findElement(DeleteButton).isDisplayed();
		Assert.assertTrue(DeleteButtonPresent);
		driver.findElement(ComputerName).clear();
		driver.findElement(ComputerName).sendKeys(ComputerUpdate);
		driver.findElement(IntroducedDate).clear();
		driver.findElement(IntroducedDate).sendKeys(IDate);
		driver.findElement(DiscontinuedDate).clear();
		driver.findElement(DiscontinuedDate).sendKeys(TDate);
	}
	
	public static void VerifyAndClickOnUpdateButton(){
		
		boolean UpdateBtnDisplayed = driver.findElement(UpdateComputerButton).isDisplayed();
		boolean UpdateBtnEnabled = driver.findElement(UpdateComputerButton).isEnabled();
		Assert.assertTrue(UpdateBtnDisplayed);
		Assert.assertTrue(UpdateBtnEnabled);
		driver.findElement(UpdateComputerButton).click();
	}
}
