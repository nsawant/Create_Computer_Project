package com.methods;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import com.locators.AddComputer;
import com.locators.EditComputer;
import com.utils.BaseClass;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.*;


public class HomePage extends BaseClass implements AddComputer, EditComputer, com.locators.HomePage{

		public static void VerifyAndClickOnAddNewButton(){
			
			boolean AddHomeBtnDisplayed = driver.findElement(AddComputer_HomeButton).isDisplayed();
			boolean AddHomeBtnEnabled = driver.findElement(AddComputer_HomeButton).isEnabled();
			Assert.assertTrue(AddHomeBtnEnabled);
			Assert.assertTrue(AddHomeBtnDisplayed);
			driver.findElement(AddComputer_HomeButton).click();
		}
		
		public static void FindComputerNameTextBox(String ComputerName){
			boolean SearchBoxPresent = driver.findElement(Search_Box).isDisplayed();
			boolean SearchBoxEditable = driver.findElement(Search_Box).isEnabled();
			if(SearchBoxPresent == true && SearchBoxEditable == true){
				driver.findElement(Search_Box).sendKeys(ComputerName);
			}else{
				System.out.println("Search Box is not visible or editable");
			}
		}

		public static void VerifyFilterByNameButton(){
			
			boolean FilterBynameBtnDisplayed = driver.findElement(Search_Button).isDisplayed();
			boolean FilterBynameBtnEnabled = driver.findElement(Search_Button).isEnabled();
			if (FilterBynameBtnDisplayed == true && FilterBynameBtnEnabled == true){
				driver.findElement(Search_Button).click();
			}else{
				System.out.println("Search Button Not Present OR Enabled");
			}
		}
		
		public static void VerifyNewComputerAddedMessage(String Computer){
			String ActualMessage = driver.findElement(NewComputerConfirmation).getText();
			String ExpectedMessage = "Done! Computer "+ Computer + " has been created";
			Assert.assertEquals(ActualMessage, ExpectedMessage);
		}
		
		public static void VerifyDeletedMessage(){
			String ActualMessage = driver.findElement(DeleteComputerConfirmation).getText();
			String ExpectedMessage = "Done! Computer has been deleted";
			Assert.assertEquals(ActualMessage, ExpectedMessage);
		}
		
		public static void VerifyEditMessage(String ComputerUpdate){
			String ActualMessage = driver.findElement(EditComputerConfirmation).getText();
			String ExpectedMessage = "Done! Computer "+ ComputerUpdate + " has been updated";
			Assert.assertEquals(ActualMessage, ExpectedMessage);
		}

		public static void VerifySearchResultPresent(){
			boolean SearchResult = driver.findElement(SearchResultPresent).isDisplayed();
			Assert.assertTrue(true);
		}
		
		public static void VerifySearchValues(String Computer){
			String SearchRead = driver.findElement(ReadSearchResult).getText();
			Assert.assertEquals(SearchRead, Computer);
		}
		
		public static void EditSearchResult(String Computer){
			
			driver.findElement(By.linkText(Computer)).click();;
			/*driver.findElement(ReadSearchResult).click();*/
			
		}
		
		public static void NoDataFound(){
			Assert.assertTrue(driver.findElement(NoDataFound).isDisplayed());
			
		}
}
