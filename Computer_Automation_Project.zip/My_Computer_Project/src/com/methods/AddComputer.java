package com.methods;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.utils.BaseClass;

public class AddComputer extends BaseClass implements com.locators.AddComputer{

	public static void VerifyComputerNameTextBox(String Computer){
		boolean ComputerNameTextBox = driver.findElement(ComputerName).isDisplayed();
		if(ComputerNameTextBox == true){
			driver.findElement(ComputerName).sendKeys(Computer);
		}
	}
	
	public static void VerifyIntroduceDateTextBox(String IntroduceDate){
		boolean IntroduceDateTextBox = driver.findElement(IntroducedDate).isDisplayed();
		if(IntroduceDateTextBox == true){
			driver.findElement(IntroducedDate).sendKeys(IntroduceDate);
		}else{
			System.out.println("Element not found");
		}
	}
	public static void VerifyDiscontinuedTextBox(String DiscontinueDate){
		boolean DiscontinuedTextBox = driver.findElement(DiscontinuedDate).isDisplayed();
		if(DiscontinuedTextBox == true){
			driver.findElement(DiscontinuedDate).sendKeys(DiscontinueDate);
		}else{
			System.out.println("Element not found");
		}
	}
	
	public static void SelectCompany(){
		WebElement dropdown = driver.findElement(Company);
		dropdown.click();
		Select select = new Select(dropdown);
		
		List<WebElement> alloptions = select.getOptions(); 
		
		for(int i =0; i<alloptions.size();i++ ){
			System.out.println(alloptions.get(i).getText());
			select.selectByVisibleText("Apple Inc.");
		}
	}
		
	public static void EditCompany(){
			WebElement dropdown = driver.findElement(Company);
			dropdown.click();
			Select select = new Select(dropdown);
			
			List<WebElement> alloptions = select.getOptions(); 
			
			for(int i =0; i<alloptions.size();i++ ){
				System.out.println(alloptions.get(i).getText());
				select.selectByVisibleText("Thinking Machines");
			}
			
		}
		
		public static void VerifyCreateComputerButton(){
			boolean CreateComputerButtonPresent = driver.findElement(CreateComputerButton).isDisplayed();
			boolean CreateComputerButtonEnabled = driver.findElement(CreateComputerButton).isEnabled();
			if (CreateComputerButtonPresent == true && CreateComputerButtonEnabled == true){
				driver.findElement(CreateComputerButton).click();
			}else{
				System.out.println("Element not found");
			}
		}
		
		public static void CancelButton(){
			boolean CancelButtonPresent = driver.findElement(CancelButton).isDisplayed();
			boolean CancelButtonEnabled = driver.findElement(CancelButton).isEnabled();
			if (CancelButtonPresent == true && CancelButtonEnabled == true){
				driver.findElement(CancelButton).click();
			}else{
				System.out.println("Element not found");
			}
		}
	
}
