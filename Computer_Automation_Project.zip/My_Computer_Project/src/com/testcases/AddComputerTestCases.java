package com.testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.methods.AddComputer;
import com.methods.HomePage;
import com.utils.BaseClass;

public class AddComputerTestCases extends BaseClass{

	
	@Parameters({"Select", "Computer", "IntroduceDate", "DiscontinueDate", "ComputerName"})
	@Test(priority=1)
	public void Create_Computer_Valid_01(String Select, String Computer, String IntroduceDate, String DiscontinueDate, String ComputerName ) throws Exception{
		BaseClass.Browser(Select);
		//Step 1 and Step 2
		HomePage.VerifyAndClickOnAddNewButton();
		Thread.sleep(100);
		//Step 3 and Step 4
		AddComputer.VerifyComputerNameTextBox(Computer);
		//Step 7
		AddComputer.VerifyIntroduceDateTextBox(IntroduceDate);
		//Step 8
		AddComputer.VerifyDiscontinuedTextBox(DiscontinueDate);
		//Step 10
		AddComputer.SelectCompany();
		//Step 5
		AddComputer.VerifyCreateComputerButton();
		Thread.sleep(100);
		//Step 11
		HomePage.VerifyNewComputerAddedMessage(Computer);
		HomePage.FindComputerNameTextBox(ComputerName);
		HomePage.VerifyFilterByNameButton();
		HomePage.VerifySearchResultPresent();
	}	
}

