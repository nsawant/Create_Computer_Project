package com.testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.methods.AddComputer;
import com.methods.EditPage;
import com.methods.HomePage;
import com.utils.BaseClass;

public class EditComputerTest extends BaseClass{


	@Parameters({"Select", "Computer", "IntroduceDate", "DiscontinueDate", "ComputerName", "ComputerUpdate", "IDate", "TDate"})
	@Test(priority=1)
	public void Read_Computer_Valid_02(String Select, String Computer, String IntroduceDate, String DiscontinueDate, String ComputerName, String ComputerUpdate, String IDate, String TDate) throws Exception{
	BaseClass.Browser(Select);
	HomePage.VerifyAndClickOnAddNewButton();
	Thread.sleep(100);
	AddComputer.VerifyComputerNameTextBox(Computer);
	AddComputer.VerifyIntroduceDateTextBox(IntroduceDate);
	AddComputer.VerifyDiscontinuedTextBox(DiscontinueDate);
	AddComputer.SelectCompany();
	AddComputer.VerifyCreateComputerButton();
	Thread.sleep(100);
	HomePage.VerifyNewComputerAddedMessage(Computer);
	/*HomePage.FindComputerNameTextBox(ComputerName);
	HomePage.VerifyFilterByNameButton();
	HomePage.VerifySearchResultPresent();*/
	HomePage.EditSearchResult(Computer);
	EditPage.UpdateComputerDetails(ComputerUpdate, IDate, TDate);
	AddComputer.EditCompany();
	EditPage.VerifyAndClickOnUpdateButton();
	HomePage.VerifyEditMessage(ComputerUpdate);
	}
}